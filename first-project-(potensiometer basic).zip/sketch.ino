int pot1 = A0;
int value1 = 0;

int pot2 = A1;
int value2 = 0;

void setup() {
  // put your setup code here, to run once:
Serial.begin(9600);
}

void loop() {
  value1 = analogRead(pot1);
  Serial.print("potensiometer 1:");
  Serial.println(value1);
  value2 = analogRead(pot2);
  Serial.print("potensiometer 2:");
  Serial.println(value2);
  Serial.println("");
  delay(500);
  

}
