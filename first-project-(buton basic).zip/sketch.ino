int ledm = 13;
int ledh = 12;
int ledb = 11;

int btnm = 10;
int btnh = 9;
int btnb = 8;

int btnstatem = 0;
int btnstateh = 0;
int btnstateb = 0;

void setup() {
  // put your setup code here, to run once:
pinMode(ledm, OUTPUT);
pinMode(ledh, OUTPUT);
pinMode(ledb, OUTPUT);
pinMode(btnm, INPUT);
pinMode(btnh, INPUT);
pinMode(btnb, INPUT);
}

void loop() {
  // put your main code here, to run repeatedly:
btnstatem = digitalRead(btnm);
btnstateh = digitalRead(btnh);
btnstateb = digitalRead(btnb);

if(btnstatem == HIGH){
  digitalWrite(ledm, HIGH);
}
else{
  digitalWrite(ledb, LOW);
  digitalWrite(ledh, LOW);
}

if(btnstateh == HIGH){
  digitalWrite(ledh, HIGH);
}
else{
  digitalWrite(ledm, LOW);
  digitalWrite(ledb, LOW);
}

if(btnstateb == HIGH){
  digitalWrite(ledb, HIGH);
}
else{
  digitalWrite(ledm, LOW);
  digitalWrite(ledh, LOW);
}

}