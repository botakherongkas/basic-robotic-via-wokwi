int ledr = 8;
int ledy = 9;
int ledg = 10;


void setup() {
  // put your setup code here, to run once:
Serial.begin(9600);
pinMode(ledr, OUTPUT);
pinMode(ledy, OUTPUT);
pinMode(ledg, OUTPUT);
}

void loop() {
  // put your main code here, to run repeatedly:
digitalWrite(ledr, HIGH);
digitalWrite(ledy, LOW);
digitalWrite(ledg, LOW);
Serial.println("Red on");
delay(5000);
digitalWrite(ledr, LOW);
digitalWrite(ledy, HIGH);
digitalWrite(ledg, LOW);
Serial.println("Yellow on");
delay(3000);
digitalWrite(ledr, LOW);
digitalWrite(ledy, LOW);
digitalWrite(ledg, HIGH);
Serial.println("Green on");
delay(5000);

}
